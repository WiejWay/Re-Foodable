let max = 8000
let min = 4000
setTimeout(LoadEnd1, Math.floor(Math.random() * (max - min + 1) ) + min);
function LoadEnd1(){
    document.querySelector(".animat h2").innerHTML = "Site loaded...";
    setTimeout(LoadEnd2,3000);
}
function LoadEnd2(){
    var anim = document.querySelector(".animat");
       anim.classList.toggle("OFF");
    scrollTo(0,0);
    setTimeout(LoadEnd3,4000);
    
}
function LoadEnd3(){
    var anim = document.querySelector(".animat.OFF");
    anim.classList.toggle("OFF2");
}

//zmiana koloru tła
var div = document.querySelector('.Body2');
var back = document.querySelector("body")

div.scrollTo(0, 0);
div.addEventListener('scroll', function() {
  var scrollPos = div.scrollTop;

  if (scrollPos >= 1000) {
    back.style.backgroundColor = 'var(--Section2-1)';}
    else{
       back.style.backgroundColor = 'var(--Section1-1)';}
    }
);
//wyszukiwarka
document.getElementById("search-button").addEventListener("click", function() {
    var searchInput = document.getElementById("search-input").value;
    alert("Dodamy tę funkcję w przyszłości ale mamy już pare przepisów,zobacz je poniżej.");
    div.scrollTo(0,700);
    });
    function Scroll(value) {
        window.scrollTo(0,value)
    }